import React, { useState } from 'react';
import { useWork } from '../context/WorkContext';

const JobSearch = () => {
  const { jobs, user, applyForJob } = useWork();
  const [filters, setFilters] = useState({
    category: '',
    location: '',
    salaryType: '',
    search: ''
  });

  const filteredJobs = jobs.filter(job => {
    return (
      (filters.category === '' || job.category === filters.category) &&
      (filters.location === '' || job.location.toLowerCase().includes(filters.location.toLowerCase())) &&
      (filters.salaryType === '' || job.salaryType === filters.salaryType) &&
      (filters.search === '' || 
        job.title.toLowerCase().includes(filters.search.toLowerCase()) ||
        job.description.toLowerCase().includes(filters.search.toLowerCase()))
    );
  });

  const handleApply = (jobId) => {
    if (!user || user.userType !== 'worker') {
      alert('Please register as a worker to apply for jobs');
      return;
    }
    
    applyForJob(jobId, {
      name: user.name,
      email: user.email,
      skills: user.skills
    });
    alert('Application submitted successfully!');
  };

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">Find Your Dream Job</h1>
          <p className="text-xl text-gray-600">Discover opportunities that match your skills and interests</p>
        </div>
        
        {/* Filters */}
        <div className="bg-white rounded-2xl shadow-lg p-6 mb-8">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Filter Jobs</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Search</label>
              <input
                type="text"
                placeholder="Job title or description..."
                value={filters.search}
                onChange={(e) => setFilters({...filters, search: e.target.value})}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-colors"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Category</label>
              <select 
                value={filters.category} 
                onChange={(e) => setFilters({...filters, category: e.target.value})}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-colors"
              >
                <option value="">All Categories</option>
                <option value="IT">IT & Software</option>
                <option value="Construction">Construction</option>
                <option value="Delivery">Delivery</option>
                <option value="Retail">Retail</option>
                <option value="Healthcare">Healthcare</option>
              </select>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Location</label>
              <input
                type="text"
                placeholder="City or state"
                value={filters.location}
                onChange={(e) => setFilters({...filters, location: e.target.value})}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-colors"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Salary Type</label>
              <select 
                value={filters.salaryType} 
                onChange={(e) => setFilters({...filters, salaryType: e.target.value})}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-colors"
              >
                <option value="">All Types</option>
                <option value="hourly">Hourly</option>
                <option value="daily">Daily</option>
                <option value="monthly">Monthly</option>
              </select>
            </div>
          </div>
        </div>

        {/* Job Listings */}
        <div className="space-y-6">
          {filteredJobs.map(job => (
            <div key={job.id} className="bg-white rounded-2xl shadow-lg border border-gray-200 p-6 hover:shadow-xl transition-shadow duration-300">
              <div className="flex flex-col lg:flex-row lg:items-start lg:justify-between">
                <div className="flex-1">
                  <div className="flex items-start justify-between mb-4">
                    <div>
                      <h3 className="text-2xl font-bold text-gray-900 mb-2">{job.title}</h3>
                      <p className="text-gray-600 font-medium mb-1">{job.employer}</p>
                      <p className="text-red-600 mb-2 flex items-center">
                        <span className="mr-2">📍</span>
                        {job.location}
                      </p>
                    </div>
                    <div className="bg-blue-100 text-blue-800 px-3 py-1 rounded-full text-sm font-medium">
                      {job.category}
                    </div>
                  </div>
                  
                  <p className="text-gray-600 mb-4 leading-relaxed">{job.description}</p>
                  
                  <div className="flex flex-wrap gap-4 mb-4">
                    <div className="bg-green-50 text-green-700 px-3 py-2 rounded-lg">
                      <span className="font-semibold">${job.salaryRange.min} - ${job.salaryRange.max}</span>
                      <span className="text-sm ml-1">{job.salaryType}</span>
                    </div>
                    <div className="bg-gray-100 text-gray-700 px-3 py-2 rounded-lg text-sm">
                      Posted: {job.postedDate}
                    </div>
                  </div>

                  {job.requirements && (
                    <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4 mb-4">
                      <p className="text-yellow-800 text-sm">
                        <strong className="font-semibold">Requirements:</strong> {job.requirements}
                      </p>
                    </div>
                  )}
                </div>

                <div className="lg:pl-6 lg:border-l lg:border-gray-200 lg:min-w-[200px]">
                  {user && user.userType === 'worker' ? (
                    <button 
                      onClick={() => handleApply(job.id)}
                      className="w-full lg:w-auto bg-green-600 hover:bg-green-700 text-white font-medium py-3 px-6 rounded-lg transition-colors duration-200 focus:outline-none focus:ring-2 focus:ring-green-500 focus:ring-offset-2"
                    >
                      Apply Now
                    </button>
                  ) : (
                    <div className="text-center lg:text-right">
                      <p className="text-sm text-gray-500 mb-2">Register as worker to apply</p>
                      <button className="bg-gray-600 hover:bg-gray-700 text-white font-medium py-2 px-4 rounded-lg transition-colors duration-200 text-sm">
                        Sign Up to Apply
                      </button>
                    </div>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>

        {filteredJobs.length === 0 && (
          <div className="bg-white rounded-2xl shadow-lg p-12 text-center">
            <div className="w-20 h-20 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-6">
              <span className="text-gray-400 text-3xl">🔍</span>
            </div>
            <h3 className="text-2xl font-semibold text-gray-900 mb-3">No jobs found</h3>
            <p className="text-gray-600 mb-6">Try adjusting your search filters or check back later for new opportunities.</p>
            <button 
              onClick={() => setFilters({ category: '', location: '', salaryType: '', search: '' })}
              className="bg-blue-600 hover:bg-blue-700 text-white font-medium py-2 px-6 rounded-lg transition-colors duration-200"
            >
              Clear Filters
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default JobSearch;